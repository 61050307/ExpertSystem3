/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expert.system.covid.pkg19;

/**
 *
 * @author luksorn
 */
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ExpertSystemCovid19 {

    /**
     * @param args the command line arguments
     */
    
    public static List<String> answer = new ArrayList<>();
    public static List<String> information = new ArrayList<>();
    
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
     public static void toAnalyzePage(){
        if((answer.get(0).equals("1")||answer.get(0).equals("2"))
            &&(answer.get(1).equals("0")||answer.get(1).equals("1"))
            &&(answer.get(2).equals("0")||answer.get(2).equals("1"))
            &&(answer.get(3).equals("0"))
            &&(answer.get(4).equals("0"))
            &&(answer.get(5).equals("0"))
            &&(answer.get(6).equals("0"))
            &&(answer.get(7).equals("0"))
            &&(answer.get(8).equals("0")||answer.get(8).equals("1"))
            &&(answer.get(9).equals("0"))
            &&(answer.get(10).equals("0"))
            &&(answer.get(11).equals("0"))
            &&(answer.get(12).equals("0"))){
            AnalysePage1_3 analyze1 = new AnalysePage1_3();
            analyze1.setVisible(true);
        }else{ if((answer.get(0).equals("2"))
            &&(answer.get(1).equals("0")||answer.get(1).equals("1"))
            &&(answer.get(2).equals("2"))
            &&(answer.get(3).equals("1"))
            &&(answer.get(4).equals("1"))
            &&(answer.get(5).equals("1")||answer.get(5).equals("2"))
            &&(answer.get(6).equals("1"))
            &&(answer.get(7).equals("0"))
            &&(answer.get(8).equals("1"))
            &&(answer.get(9).equals("1"))
            &&(answer.get(10).equals("0"))
            &&(answer.get(11).equals("0"))
            &&(answer.get(12).equals("0")||answer.get(12).equals("1"))){
            AnalysePage4_5 analyze2 = new AnalysePage4_5();
            analyze2.setVisible(true);
        }else{ if((answer.get(0).equals("2"))
            &&(answer.get(1).equals("1")||answer.get(1).equals("2"))
            &&(answer.get(2).equals("2"))
            &&(answer.get(3).equals("1"))
            &&(answer.get(4).equals("1"))
            &&(answer.get(5).equals("2"))
            &&(answer.get(6).equals("1")||answer.get(6).equals("2"))
            &&(answer.get(7).equals("1")||answer.get(7).equals("2"))
            &&(answer.get(8).equals("1"))
            &&(answer.get(9).equals("1"))
            &&(answer.get(10).equals("1"))
            &&(answer.get(11).equals("1"))
            &&(answer.get(12).equals("1"))){
            AnalysePage6_7 analyze3 = new AnalysePage6_7();
            analyze3.setVisible(true);
        }else{ if((answer.get(0).equals("2"))
            &&(answer.get(1).equals("2"))
            &&(answer.get(2).equals("2"))
            &&(answer.get(3).equals("1"))
            &&(answer.get(4).equals("1"))
            &&(answer.get(5).equals("2"))
            &&(answer.get(6).equals("1")||answer.get(6).equals("2"))
            &&(answer.get(7).equals("1")||answer.get(7).equals("2"))
            &&(answer.get(8).equals("1"))
            &&(answer.get(9).equals("1"))
            &&(answer.get(10).equals("1"))
            &&(answer.get(11).equals("1"))
            &&(answer.get(12).equals("2"))){
            AnalysePage8_9 analyze4 = new AnalysePage8_9();
            analyze4.setVisible(true);
        } else {
            AnalysePage analyze5 = new AnalysePage();
            analyze5.setVisible(true);
        }}}}
    
     }
            
 }

